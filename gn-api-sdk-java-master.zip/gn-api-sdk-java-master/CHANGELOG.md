# 2.0.0
- Added: API Open Finance
- Added: API Pagamentos
- Added: new endpoints of API Pix 
- Updated: PixSend example
- Updated: rename "pix_cert" to "certificate" in credentials.json

# 1.0.2

- Fix: Error message

# 1.0.1

- Fix: Error message

# 1.0.0

- Added: API Pix endpoints

# 0.2.6

- Added: new endpoint (one step)

# 0.2.5

- Added: new endpoint (settle charge)
- Added: new endpoint (settle carnet parcel)

# 0.2.4

- Added: new endpoint (create charge balance sheet)

# 0.2.3

- Added: new endpoint (update plan)
- Added: new endpoint (create subscription history)

# 0.2.2

- Added: forward `partner-token` header

# 0.2.1

- Fix: SDK version sent at request body

# 0.2.0

- Added: new endpoint (link charge)
- Updated: docs

# 0.1.0

- Initial release
